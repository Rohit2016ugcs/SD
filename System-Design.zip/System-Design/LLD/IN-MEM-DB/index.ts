import { Db } from "./db";
import { Qtype } from "./enum";

export class Main {
  private db: Db;
  constructor() {
    this.db = new Db();
    this.process()
  }
  process() {
    this.db.createTable("profile",{ firstName: 'string', lastName: 'string', marks: 'number', subjects: 'object', student: 'boolean' })
    this.db.queryTable("profile1",Qtype.FIND,{},{});
    this.db.queryTable("profile",Qtype.FIND,{},{});
     this.db.queryTable("profile",Qtype.INSERT,{firstName: 'rohit', lastName: 'kumar', marks: 54.56, subjects: ['maths','physics'],student: true},{});
    this.db.queryTable("profile",Qtype.INSERT,{firstName: 'rohit-1', lastName: 'kumar-1', marks: 84.56, subjects: ['maths','english'],student: false},{});
    this.db.queryTable("profile",Qtype.INSERT,{firstName: 'rohit-2', lastName: 'kumar-2', marks: 43, subjects:['bio','physics'],student: true},{});
    this.db.queryTable("profile",Qtype.INSERT,{firstName: 'rohit-3', lastName: 'kumar-3', marks: 91.34, subjects: ['hindi','physics','maths'],student: true},{});
    this.db.queryTable("profile",Qtype.FIND,{},{firstName: 'rohit', marks: 54.56});
    this.db.queryTable("profile",Qtype.DELETE,{},{student: true})
    this.db.queryTable("profile",Qtype.UPDATE,{marks: 19.21},{firstName: 'rohit-3'})
    this.db.queryTable("profile",Qtype.FIND,{},{lastName: 'kumar-3'});
    this.db.queryTable("profile",Qtype.UPDATE,{marks: 99.21},{firstName: 'rohit-2'})
    this.db.queryTable("profile",Qtype.FIND,{},{});
    // this.db.queryTable("profile",Qtype.FIND,{},{});
    // this.db.queryTable("profile",Qtype.FIND,{},{});

  }
}