export const enum Qtype {
  INSERT = "insert",
  UPDATE = "update",
  DELETE = "delete",
  FIND = "find"
}