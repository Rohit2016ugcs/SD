import { Row } from "./row";
import { row } from "./type";

export class Table {
  private rows: row<any>[];
  private name: stirng;
  private cols: row<string>;
  constructor(name: string, cols: row<string>) {
    this.rows = [];
    this.cols = cols;
    this.name = name;
  }
  private validateCols(filter: row<any>) {
    return Object.keys(filter).reduce((a,c) => a&&(this.cols[c as keyof typeof this.cols] == typeof filter[c]),true);
  }
  private getFilteredRows(filter: row<any>, rev: boolean=false) {
    return !rev?this.rows.filter(row => Object.keys(filter).reduce((a,c) => a&&row[c]===filter[c],true)):
      this.rows.filter(row => !Object.keys(filter).reduce((a,c) => a&&row[c]===filter[c],true));
  }
  
  insert(row: row<any>) {
    if(!this.validateCols(row)){
      console.log("invalid schema");
      return;
    }
    this.rows.push(new Row(row));
  }
  get(filter?: row<any>) {
    if(!filter) return this.rows;
    return this.getFilteredRows(filter);
  }
  update(row: row<any>, filter?: row<any>) {
    let filteredRows=this.rows;
    if(!this.validateCols(row)){
      console.log("invalid schema update aborted!!")
      return;
    }
    if(filter)filteredRows = this.getFilteredRows(filter);
    for(const r of filteredRows) {
      for(const key in row) {
        r[key]=row[key];
      }
    }
  }
  delete(filter?: row<any>) {
    if(!filter) {
      this.rows=[];
      return;
    }
    this.rows = this.getFilteredRows(filter, true);
  }
}