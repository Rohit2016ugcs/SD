import { row } from "./type";

export class Row {
  [key: string]: any;
  constructor(row: row<any>) {
    for(const key in row) this[key]=row[key];
  }
}