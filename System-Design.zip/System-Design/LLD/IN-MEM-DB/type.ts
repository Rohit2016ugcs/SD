export type row<T> = {
  [key: string]: T
}