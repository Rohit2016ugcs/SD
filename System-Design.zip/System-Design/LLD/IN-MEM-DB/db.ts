import { Qtype } from "./enum";
import { Table } from "./table";
import { row } from "./type";

export class Db {
  private tables: Map<string, Table>;
  constructor() {
    this.tables = new Map();
  }
  createTable(name: string, schema: row<any>) {
    let table = this.tables.get(name);
    if (table) {
      console.log("table already exist");
      return;
    }
    table = new Table(name, schema);
    this.tables.set(name, table);
  }
  queryTable(name: string, qtype: Qtype, row?: row<any>, filter?: row<any>) {
    const table = this.tables.get(name);
    if (!table) {
      console.log("table not found");
      return;
    }
    switch (qtype) {
      case Qtype.INSERT: {
        table.insert(row!);
        break;
      }
      case Qtype.UPDATE: {
        table.update(row!,filter);
        break;
      }
      case Qtype.DELETE: {
        table.delete(filter);
        break;
      }
      case Qtype.FIND: {
        console.log(table.get(filter));
        break;
      }
    }
  }
}
