export const enum RequestMethod {
  POST,
  GET
}