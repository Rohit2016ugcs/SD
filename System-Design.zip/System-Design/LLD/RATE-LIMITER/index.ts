import { RequestMethod } from "./enum";
import { Network } from "./network";
import { Server } from "./server";
import { User } from "./user";

export class Main {
  private server: Server;
  constructor() {
    this.server = new Server();
    this.process()
  }
  async process() {
    const u1=new User();
    const u2=new User();
    const n1 = new Network();    
    const n2 = new Network();
    console.log(this.server.route(n1.createRequest(u1.id,"/getdata",RequestMethod.GET)))
    console.log(this.server.route(n1.createRequest(u1.id,"/getdata",RequestMethod.GET)))
    console.log(this.server.route(n1.createRequest(u1.id,"/getdata",RequestMethod.GET)))
    console.log(this.server.route(n1.createRequest(u1.id,"/getdata",RequestMethod.POST,"data-1")))
    console.log(this.server.route(n1.createRequest(u1.id,"/getdata",RequestMethod.GET)))
    console.log(this.server.route(n1.createRequest(u1.id,"/getdata",RequestMethod.GET)))
await new Promise(r => setTimeout(r,5000));
    console.log(this.server.route(n1.createRequest(u1.id,"/getdata",RequestMethod.POST,"data-2")))
    console.log(this.server.route(n1.createRequest(u1.id,"/getdata",RequestMethod.GET)))
    console.log(this.server.route(n1.createRequest(u1.id,"/getdata",RequestMethod.GET)))
    console.log(this.server.route(n1.createRequest(u1.id,"/getdata",RequestMethod.GET)))
    console.log(this.server.route(n2.createRequest(u2.id,"/getdata",RequestMethod.GET)))
  }
}