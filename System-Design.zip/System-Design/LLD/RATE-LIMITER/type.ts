export type Bucket = {
  tokenCount: number;
  updatedAt: number;
}