import { RequestMethod } from "./enum";
import { RateLimit } from "./rate-limit";
import { Request } from './request';

export class Server {
  private rateLimit: RateLimit;
  private data: string[];
  constructor() {
    this.rateLimit = new RateLimit();
    this.data = [];
  }
  route(request: Request) {
    if(this.rateLimit.isRateLimit(request)) {
      return {status: 429, reason: "you are rate limited. try later"}
    }
    switch(request.method){
      case RequestMethod.POST: {
        return this.post(request);
      }
      case RequestMethod.GET: {
        return this.get();
      }
      default: {
        return "route not found"
      }
    }
  }

  get() {
    return this.data;
  }
  post(request: Request) {
    if(!request.body) {
      return "post request missing body";
    }
    if(request.body) {
      this.data.push(request.body);
      return "data posted";
    }
  }

  
}