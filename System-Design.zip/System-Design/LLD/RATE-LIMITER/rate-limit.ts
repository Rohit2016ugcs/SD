import { Bucket } from "./type";
import { Request } from './request';

export class RateLimit {
  private buckets: Map<string, Bucket>
  private tokenRate: number;
  private tokenLimit: number;
  constructor() {
    this.buckets = new Map();
    this.tokenRate = 0.2;
    this.tokenLimit = 5;
  }
  isRateLimit(request: Request) {
    let bucket = this.buckets.get(request.ip);
    const currentTime = Date.now();
    if(!bucket) bucket = { tokenCount: this.tokenLimit, updatedAt: currentTime };
    bucket.tokenCount=Math.min(bucket.tokenCount+Math.floor(this.tokenRate*(currentTime-bucket.updatedAt)*0.001),this.tokenLimit);
    bucket.updatedAt=currentTime;
    console.log(request.ip,bucket)
    if(bucket.tokenCount == 0) return true;
    bucket.tokenCount-=1;
    this.buckets.set(request.ip, bucket);
    return false;
  }
}