import { randomUUID } from "crypto";
import { Request } from './request';
import { RequestMethod } from "./enum";

export class Network {
  ip: string;
  constructor() {
    this.ip = randomUUID();
  }
  createRequest(userId: string, url: string, method: RequestMethod, body?: string) {
    return new Request(userId, url, method, this.ip, body);
  }
}