import { RequestMethod } from "./enum";
import { Network } from "./network";

export class Request {
  userId: string;
  url: string;
  method: RequestMethod;
  ip: string;
  body?: string;
  constructor(userId: string, url: string, method: RequestMethod, ip: string, body?: string) {
    this.userId = userId;
    this.url = url;
    this.method = method;
    this.ip = ip;
    this.body = body;
  }
}