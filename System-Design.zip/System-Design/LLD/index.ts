// import { Main } from './LLD/PARKING-LOT';
// new Main()
import { error } from 'console';
import express from 'express';
import { get } from 'http';
import jwt from 'jsonwebtoken'
const app = express();
app.get('/token/:userid',(req, res) => {
  const token = jwt.sign({ userid: req.params.userid },'secret',{ expiresIn: '1h' })
  res.send({ token })
})
const validateUser = (req,res,next) => {
  const token = req.headers.authorization.split('Bearer ')[1];
  console.log(token)
  jwt.verify(token, 'secret',(error, data) => {
    if(error)return res.send("invalid token");
    next();
  })
}
app.get('/app/:userid',validateUser,(req,res) => {
  return res.send(req.params.userid);
})
app.post('/app/:userid',validateUser,(req,res) => {
  return res.send(req.params.userid);
})
app.listen(3000, () => console.log('app started'))

const getApi = async ()  => {
  const response = await fetch("https://e2f47c2f-9094-43d1-be91-432a172d0d47-00-3gdh5x6efzcys.sisko.replit.dev/app/123",{
    method: 'post',
    headers: {
      'authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyaWQiOiIxMjMiLCJpYXQiOjE3NDA5ODc5OTUsImV4cCI6MTc0MDk5MTU5NX0.9FORzURoeOfKfWtUN1HuGlbAwftmR81u1VdW-Dt37B8'
    }
  })
  const data = await response.json();
  console.log(data);
}
getApi();