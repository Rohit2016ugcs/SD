import { randomUUID } from "crypto";

export class Product {
  id: string;
  private name: string;
  private price: number;
  private vendor: string;
  private users: string[];
  constructor(name: string, price: number, vendor: string) {
    this.id = randomUUID();
    this.name = name;
    this.price = price;
    this.vendor = vendor;
    this.users = [];
  }
  getMeta() {
    return {
      name: this.name,
      price: this.price
    }
  }
  updatePrice(vendorId: string, price: number) {
    if(this.vendor !== vendorId) {
      console.log("only vendor can update price");
      return -1;
    }
    this.price = price;
  }
  getSubscribers() {
    return this.users;
  }
  subscribe(userId: string) {
    const user = this.users.find(u => u === userId);
    if(user) return;
    this.users.push(userId);
  }
  unSubscribe(userId: string) {
    const user = this.users.find(u => u===userId);
    if(!user) return;
    this.users = this.users.filter(u => u!==userId);
  }
  
}