import { randomUUID } from "crypto";
import { Notification, UserNotification } from "./type";
import { NotificationChannel, NotificationStatus } from "./enum";

export class User {
  id: string;
  private name: string;
  private notifications: UserNotification[];
  private notificationChannel: NotificationChannel[];
  constructor(name: string, channel: NotificationChannel[]) {
    this.id= randomUUID();
    this.name = name;
    this.notifications = [];
    this.notificationChannel = channel;
  }
  read() {
    return this.notifications.filter(n => {
      if(n.status == NotificationStatus.UNREAD) {
        n.status = NotificationStatus.READ
        return true;
      }
      return false;
    });
  }
  push(notification: Notification) {
    for(const channel of this.notificationChannel) {
      this.notifications.push({ ...notification, channel });
    }
  }
}