import { NotificationChannel } from "./enum";
import { NotificationManager } from "./notificationManager";

export class Main {
  private notificationManager: NotificationManager;
  constructor() {
    this.notificationManager = new NotificationManager();
    this.process()
  }
  process() {
    const u1 = this.notificationManager.createUser("rohit-1",[NotificationChannel.EMAIL, NotificationChannel.PUSH]);
    const u2 = this.notificationManager.createUser("rohit-2",[NotificationChannel.SMS, NotificationChannel.PUSH]);
    const p11 = this.notificationManager.createProduct("p-11",34.56, "v-1");
    const p12 = this.notificationManager.createProduct("p-12",66, "v-1");
    const p13 = this.notificationManager.createProduct("p-13",56.98, "v-1");

    const p21 = this.notificationManager.createProduct("p-21",354.12, "v-2");
    const p22 = this.notificationManager.createProduct("p-22",254.12, "v-2");
    const p23 = this.notificationManager.createProduct("p-23",154.12, "v-2");
    this.notificationManager.readNotifications(u1);
    this.notificationManager.readNotifications(u2);
    this.notificationManager.subscribe(u1,p11)
    this.notificationManager.updatePrice('v-1',p11,43.23);
    this.notificationManager.readNotifications(u1);
    this.notificationManager.readNotifications(u2);
    this.notificationManager.subscribe(u1,p22);
    this.notificationManager.updatePrice('v-2',p22,43.23);
    this.notificationManager.unSubscribe(u1,p11);
    this.notificationManager.updatePrice('v-1',p11,43.23);
    this.notificationManager.readNotifications(u1);
    this.notificationManager.readNotifications(u2);
  }
}