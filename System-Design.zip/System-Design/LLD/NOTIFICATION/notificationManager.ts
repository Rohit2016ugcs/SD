import { randomUUID } from "crypto";
import { NotificationChannel, NotificationStatus } from "./enum";
import { Product } from "./product";
import { User } from "./user";

export class NotificationManager {
  private users: Map<string, User>;
  private products: Map<string, Product>;
  constructor() {
    this.users = new Map();
    this.products = new Map();
  }
  createUser(name: string, channel: NotificationChannel[]) {
    const user = new User(name, channel);
    this.users.set(user.id, user);
    return user.id;
  }
  createProduct(name: string, price: number, vendor: string) {
    const product = new Product(name, price, vendor);
    this.products.set(product.id, product);
    return product.id;
  }
  readNotifications(userId: string) {
    const user = this.users.get(userId);
    if(!user){
      console.log("user not found");
      return;
    }
    console.log(user.read());
  }
  updatePrice(vendorId: string, productId: string, price: number) {
    const product = this.products.get(productId);
    if(!product) {
      console.log("product not found")
      return;
    }
    const meta = product.getMeta();
    const status = product.updatePrice(vendorId, price);
    if(status == -1)return;
    for(const userId of product.getSubscribers()) {
      this.users.get(userId)?.push({
        id: randomUUID(),
        content: { productId, name: meta.name, price: meta.price, updatedPrice: price },
        status: NotificationStatus.UNREAD
      })
    }
  }
  subscribe(userId: string, productId: string) {
    const user = this.users.get(userId);
    if(!user){
      console.log("user not found");
      return;
    }
    const product = this.products.get(productId);
    if(!product) {
      console.log("product not found")
      return;
    }
    product.subscribe(userId);
  }
  unSubscribe(userId: string, productId: string) {
    const user = this.users.get(userId);
    if(!user){
      console.log("user not found");
      return;
    }
    const product = this.products.get(productId);
    if(!product) {
      console.log("product not found")
      return;
    }
    product.unSubscribe(userId);
  }
}