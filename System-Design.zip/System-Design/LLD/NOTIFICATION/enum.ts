export const enum NotificationChannel {
  EMAIL,
  SMS,
  PUSH
}

export const enum NotificationStatus {
  UNREAD,
  READ
}