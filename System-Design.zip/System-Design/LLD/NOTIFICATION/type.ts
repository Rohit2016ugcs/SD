import { NotificationChannel, NotificationStatus } from "./enum";

export type Notification = {
  id: string;
  content: any;
  status: NotificationStatus;
}

export type UserNotification = Notification & {
  channel: NotificationChannel;
}