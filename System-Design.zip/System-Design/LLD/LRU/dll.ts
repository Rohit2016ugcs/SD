import { Enode } from "./type";

export class Dll {
  head: Enode;
  tail: Enode;
  constructor() {
    this.head = this.tail = null;
  }
  add(node: Enode) {
    if(!node) return;
    node.prev = this.head;
    if(this.head)this.head.next = node;
    this.head=node;
    if(!this.tail)this.tail=this.head;
  }
  remove(node: Enode) {
    if(!node) return;
    if(node.prev)node.prev.next=node.next;
    if(node.next)node.next.prev=node.prev;
    if(node==this.head)this.head=this.head.prev;
    if(node==this.tail)this.tail=this.tail.next;
  }
}