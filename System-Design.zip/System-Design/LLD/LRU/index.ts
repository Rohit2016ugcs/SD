import { Cache } from "./cache";

export class Main {
  private cache: Cache;
  constructor() {
    this.cache = new Cache(5);
    this.process();
  }
  process() {
    this.cache.get(10);
    this.cache.put(10,"rohit");
    this.cache.put(20,"r-1");
    this.cache.put(30,"r-2");
    this.cache.put(40,"r-3");
    this.cache.put(50,"r-4");
    this.cache.put(60,"r-5");
    this.cache.get(10);
    this.cache.get(20);    
    this.cache.get(40);
    this.cache.get(50);
    this.cache.put(70,"r-6");
    this.cache.put(80,"r-7");
    this.cache.get(40);
    this.cache.get(30);    
    this.cache.get(20);    
    this.cache.get(60);
    this.cache.put(90,"r-8");
    this.cache.get(70);
  }
}