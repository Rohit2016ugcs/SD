import { Node } from "./node";

export type Enode = Node | null;