import { Enode } from "./type";

export class Node {
  key: any;
  val: any;
  prev: Enode;
  next: Enode;
  constructor(key: any, val: any) {
    this.key = key;
    this.val = val;
    this.prev = this.next=null;
  }
}