import { Dll } from "./dll";
import { Node } from "./node";

export class Cache {
  private size: number;
  private nodeMap: Map<any,Node>;
  private dll: Dll;
  constructor(size: number) {
    this.size=size;
    this.nodeMap = new Map();
    this.dll = new Dll();
  }
  get(key: any) {
    const node = this.nodeMap.get(key);
    if(!node) {
      console.log(-1);
      return;
    }
    this.dll.remove(node);
    this.dll.add(node);
    console.log(node.val);
  }
  put(key: any, val: any) {
    let node = this.nodeMap.get(key);
    if(node) {
      node.val = val;
      return;
    }
    node = new Node(key, val);
    if(this.size == this.nodeMap.size) {
      this.nodeMap.delete(this.dll.tail?.key);
      this.dll.remove(this.dll.tail);
    }
    this.dll.add(node);
    this.nodeMap.set(key,node);
  }
}