import { Publisher } from "./publisher";
import { Subscriber } from "./subscriber";
import { Topic } from "./topic";
import { Event } from "./type";

export class PubSub {
  private publishers: Map<string, Publisher>;
  private subscribers: Map<string,Subscriber>;
  private topics: Map<string, Topic>;
  constructor() {
    this.publishers = new Map();
    this.subscribers = new Map();
    this.topics = new Map();
  }
  createPublisher(){
    const publisher = new Publisher();
    this.publishers.set(publisher.id, publisher);
    return publisher.id;
  }
  createSubscriber(){
    const subscriber = new Subscriber();
    this.subscribers.set(subscriber.id, subscriber);
    return subscriber.id;
  }
  createTopic(){
    const topic = new Topic();
    this.topics.set(topic.id, topic);
    return topic.id;
  }
  publish(publisherId: string, topicId: string, event: Event) {
    const publisher = this.publishers.get(publisherId);
    if(!publisher) {
      console.log("invalid publisher");
      return;
    }
    const topic = this.topics.get(topicId);
    if(!topic) {
      console.log("topic not found");
      return;
    }
    topic.publish(event);
  }

  consume(subscriberId: string, topicId: string) {
    const subscriber = this.subscribers.get(subscriberId);
    if(!subscriber) {
      console.log("invalid subscriber");
      return;
    }
    const topic = this.topics.get(topicId);
    if(!topic) {
      console.log("topic not found");
      return;
    }
    const userEvent = topic.get(subscriberId);
    if(!Array.isArray(userEvent)) {
      console.log(userEvent);
      return;
    }
    console.log(userEvent)
  }
  subscribe(subscriberId: string, topicId: string) {
    const subscriber = this.subscribers.get(subscriberId);
    if(!subscriber) {
      console.log("invalid subscriber");
      return;
    }
    const topic = this.topics.get(topicId);
    if(!topic) {
      console.log("topic not found");
      return;
    }
    topic.subscribe(subscriberId);
  }
  unSubscribe(subscriberId: string, topicId: string) {
    const subscriber = this.subscribers.get(subscriberId);
    if(!subscriber) {
      console.log("invalid subscriber");
      return;
    }
    const topic = this.topics.get(topicId);
    if(!topic) {
      console.log("topic not found");
      return;
    }
    topic.unSubscribe(subscriberId);
  }
}