import { PubSub } from "./pub-sub";

export class Main {
  private pubsub: PubSub;
  constructor() {
    this.pubsub = new PubSub();
    this.process()
  }
  process() {
    const s1 = this.pubsub.createSubscriber();
    const s2 = this.pubsub.createSubscriber();
    const p1 = this.pubsub.createPublisher();
    const p2 = this.pubsub.createPublisher();
    const t1 = this.pubsub.createTopic();
    const t2 = this.pubsub.createTopic();
    this.pubsub.consume(s1,t1);
    this.pubsub.consume(s2,t2);
    this.pubsub.publish(p1,t2, { id: "id-1" , content: "message-1"})
    this.pubsub.subscribe(s1,t2);
    this.pubsub.consume(s1,t2);
    this.pubsub.subscribe(s2,t2);    
    this.pubsub.subscribe(s2,t1); 
    this.pubsub.subscribe(s1,t1);


    this.pubsub.publish(p2,t2, { id: "id-2" , content: "message-2"})
    this.pubsub.publish(p1,t2, { id: "id-3" , content: "message-3"})
    this.pubsub.publish(p2,t2, { id: "id-4" , content: "message-4"})
    this.pubsub.consume(s1,t2);
    this.pubsub.consume(s2,t2);

    this.pubsub.publish(p2,t1, { id: "id-1" , content: "t-1-message-1"})
    this.pubsub.publish(p2,t1, { id: "id-2" , content: "t-1-message-2"})


    this.pubsub.consume(s2,t1);
    this.pubsub.consume(s1,t1);

  }
}