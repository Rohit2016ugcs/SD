import { randomUUID } from "crypto";

export class Subscriber {
  id: string;
  constructor() {
    this.id=randomUUID();
  }
}