export type Event = {
  id: string;
  content: string;
}

export type Subscriber = {
  id: string;
  offset: number;
}