import { randomUUID } from "crypto";

export class Publisher {
  id: string;
  constructor() {
    this.id = randomUUID();
  }
}