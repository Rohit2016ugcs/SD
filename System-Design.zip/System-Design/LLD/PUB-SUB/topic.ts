import { randomUUID } from "crypto";
import { Event, Subscriber } from "./type";

export class Topic {
  id: string;
  private events: Event[];
  private subscribers: Subscriber[];
  constructor() {
    this.events = [];
    this.subscribers=[];
    this.id = randomUUID();
  }
  publish(event: Event) {
    this.events.push(event);
  }
  get(subscriberId: string) {
    const subscriber = this.subscribers.find(s => s.id === subscriberId);
    if(!subscriber) {
      return ("not subscribed to topic");
    }
    const events = this.events.slice(subscriber.offset);
    subscriber.offset+=events.length;
    return events;
  }
  subscribe(subscriberId: string) {
    const subscriber = this.subscribers.find(s => s.id === subscriberId);
    if(subscriber) return;
    this.subscribers.push({ id: subscriberId, offset: 0 });
  }
  unSubscribe(subscriberId: string) {
    const subscriber = this.subscribers.find(s => s.id === subscriberId);
    if(!subscriber)return;
    this.subscribers = this.subscribers.filter(s => s.id!== subscriberId);
  }
}