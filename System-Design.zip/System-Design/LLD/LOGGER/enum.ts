export const enum LogLevel {
  INFO,
  WARN,
  ERROR,
  DEBUG
}

export const enum Logger {
  FILE,
  CONSOLE,
  DB,
  DEFAULT
}