import path from "path";
import { Logger, LogLevel } from "./enum";
import fs from 'fs';

export class DefaultLogger {
  name: Logger;
  logPath: string;
  constructor() {
    this.name = Logger.DEFAULT;
    this.logPath = path.join(process.cwd(), '/LLD/LOGGER/log/default.log')
  }
  log(message: string, level: LogLevel) {
    fs.appendFileSync(this.logPath, JSON.stringify({ message, level }, null, 2));
  }
}