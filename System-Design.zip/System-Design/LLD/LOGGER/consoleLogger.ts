import path from "path";
import { Logger, LogLevel } from "./enum";
import fs from 'fs';

export class ConsoleLogger {
  name: Logger;
  logPath: string;
  constructor() {
    this.name = Logger.CONSOLE;
    this.logPath = path.join(process.cwd(), '/LLD/LOGGER/log/console.log')
  }
  log(message: string, level: LogLevel) {
    fs.appendFileSync(this.logPath, JSON.stringify({ message, level }, null, 2));
  }
}