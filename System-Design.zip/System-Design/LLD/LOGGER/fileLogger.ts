import path from "path";
import { Logger, LogLevel } from "./enum";
import fs from 'fs';

export class FileLogger {
  name: Logger;
  logPath: string;
  constructor() {
    this.name = Logger.FILE;
    this.logPath = path.join(process.cwd(), '/LLD/LOGGER/log/file.log')
  }
  log(message: string, level: LogLevel) {
    fs.appendFileSync(this.logPath, JSON.stringify({ message, level },null, 2));
  }
}