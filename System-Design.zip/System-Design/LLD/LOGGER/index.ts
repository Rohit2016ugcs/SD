import { Logger, LogLevel } from "./enum";
import { LogManager } from "./logManager";

export class Main {
  private logger: LogManager;
  constructor() {
    this.logger = new LogManager();
    this.process();
  }
  process() {
    this.logger.log([Logger.CONSOLE, Logger.DEFAULT], LogLevel.INFO,"this is info log-1");
    this.logger.log([Logger.DB, Logger.FILE], LogLevel.ERROR,"this is error log-1");
    this.logger.log([Logger.CONSOLE, Logger.DB], LogLevel.DEBUG,"this is debug log-1");
    this.logger.log([Logger.DEFAULT], LogLevel.INFO,"this is info log-2");
    this.logger.log([Logger.CONSOLE], LogLevel.ERROR,"this is error log-2");
  }
}