import { ConsoleLogger } from "./consoleLogger";
import { DbLogger } from "./dbLogger";
import { DefaultLogger } from "./defaultLogger";
import { Logger, LogLevel } from "./enum";
import { FileLogger } from "./fileLogger";

export class LogManager {
  private fileLogger: FileLogger;
  private dbLogger: DbLogger;
  private consoleLogger: ConsoleLogger;
  private defaultLogger: DefaultLogger;
  constructor() {
    this.fileLogger = new FileLogger();
    this.dbLogger = new DbLogger();
    this.consoleLogger = new ConsoleLogger();
    this.defaultLogger = new DefaultLogger();
  }
  log(loggerList: Logger[], level: LogLevel, message: string) {
    for(const logger of loggerList) {
      switch(logger) {
        case Logger.FILE: {
          this.fileLogger.log(message,level);
          break;
        }
        case Logger.CONSOLE: {
          this.consoleLogger.log(message, level);
          break;
        }
        case Logger.DB: {
          this.dbLogger.log(message, level);
          break;
        }
        case Logger.DEFAULT: {
          this.defaultLogger.log(message, level);
          break;
        }
        default: {
          console.log("invalid logger")
        }
      }
    }
  }
}