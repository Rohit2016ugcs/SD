import path from "path";
import { Logger, LogLevel } from "./enum";
import fs from 'fs';

export class DbLogger {
  name: Logger;
  logPath: string;
  constructor() {
    this.name = Logger.DB;
    this.logPath = path.join(process.cwd(), '/LLD/LOGGER/log/db.log')
  }
  log(message: string, level: LogLevel) {
    fs.appendFileSync(this.logPath, JSON.stringify({ message, level }, null, 2));
  }
}