import { randomUUID } from "crypto";
import { UserAccess } from "./type";
import { AccessLevel } from "./enum";

export class File {
  id: string;
  owner: string;
  private name: string;
  private content: string;
  private updatedAt: Date;
  private users: UserAccess[];
  constructor(name: string, userId: string, content: string){
    this.id = randomUUID();
    this.name = name;
    this.owner = userId;
    this.content=content;
    this.users = [];
    this.updatedAt = new Date()
  }
  update(userId: string, content: string) {
    if(userId !== this.owner && !this.users.find(u => u.id === userId && u.level === AccessLevel.WRITE)){
      console.log("you dont have permission to update file")
      return;
    }
    this.content = content;
    this.updatedAt = new Date();
  }
  read(userId: string) {
    if(userId !== this.owner && !this.users.find(u => u.id === userId)){
      return ("you dont have permission to read file")
    }
    return {
      content: this.content,
      modifiedAt: this.updatedAt
    }
  }

  manageAccess(ownerId: string, user: UserAccess) {
    if(ownerId !== this.owner) {
      console.log("only owner can manage access")
      return;
    }
    const currentUser = this.users.find(u => u.id === user.id)
    if(currentUser && user.level === AccessLevel.NONE){
      this.users = this.users.filter(u => u.id !== currentUser.id);
      return;
    }
    if(currentUser){
      currentUser.level = user.level;
      return;
    }
    this.users.push(user);
  }
  
}