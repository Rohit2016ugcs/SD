import { AccessLevel } from "./enum";

export type UserAccess = {
  id: string;
  level: AccessLevel;
}