import { AccessLevel } from "./enum";
import { FileManager } from "./FileManager";

export class Main {
  private fileManager: FileManager;
  constructor() {
    this.fileManager = new FileManager();
    this.process();
  }
  process() {
    const u1 = this.fileManager.createUser();
    const u2 = this.fileManager.createUser();
    const f1 = this.fileManager.createFile(u1,"file-1","this is file-1")
    const f2 = this.fileManager.createFile(u2,"file-2","this is file-2")
    const f3 = this.fileManager.createFile(u1,"file-3","this is file-3")
    this.fileManager.readFile(u1,f1!);    
    this.fileManager.readFile(u2,f1!);
    this.fileManager.manageAccess(f1!,u1,u2,AccessLevel.READ)
    this.fileManager.readFile(u2,f1!);    
    this.fileManager.readFile(u2,f3!);
    this.fileManager.manageAccess(f3!,u1,u2,AccessLevel.READ)
    this.fileManager.readFile(u2,f3!);
    this.fileManager.updateFile(u1,f1!,"this is new content-f1");    
    this.fileManager.readFile(u2,f1!);
    this.fileManager.deleteFile(u1,f1!);
    this.fileManager.readFile(u2,f1!);

  }
}