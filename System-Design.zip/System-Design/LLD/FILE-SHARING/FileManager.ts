import { AccessLevel } from "./enum";
import { File } from "./file";
import { User } from "./user";

export class FileManager {
  private users: Map<string, User>;
  private files: Map<string, File>;
  constructor() {
    this.users = new Map();
    this.files = new Map();
  }
  createUser() {
    const user = new User();
    this.users.set(user.id, user);
    return user.id;
  }
  createFile(userId: string, name: string, content: string) {
    const user = this.users.get(userId);
    if(!user) {
      console.log("user not found");
      return;
    }
    const file = new File(name, userId, content);
    this.files.set(file.id, file);
    return file.id;
  }
  deleteFile(userId: string, fileId: string) {
    const file = this.files.get(fileId);
    if(!file){
      console.log("file not found");
      return;
    }
    if(file.owner !== userId) {
      console.log("only owner can delete file");
      return;
    }
    this.files.delete(fileId);
  }
  readFile(userId: string, fileId: string) {
    const user = this.users.get(userId);
    if(!user) {
      console.log("user not found");
      return;
    }
    const file = this.files.get(fileId);
    if(!file){
      console.log("file not found");
      return;
    }
    console.log(file.read(userId))
  }
  updateFile(userId: string, fileId: string, content: string) {
    const user = this.users.get(userId);
    if(!user) {
      console.log("user not found");
      return;
    }
    const file = this.files.get(fileId);
    if(!file){
      console.log("file not found");
      return;
    }
    file.update(userId,content);
  }
  manageAccess(fileId: string, ownerId: string, userId: string, level: AccessLevel) {
    const file = this.files.get(fileId);
    if(!file){
      console.log("file not found");
      return;
    }
    file.manageAccess(ownerId, { id: userId, level })
  }
}