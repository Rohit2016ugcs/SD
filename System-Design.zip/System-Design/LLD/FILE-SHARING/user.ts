import { randomUUID } from "crypto";

export class User {
  id: string;
  constructor() {
    this.id = randomUUID();
  }
}