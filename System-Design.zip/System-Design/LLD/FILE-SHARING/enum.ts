export const enum AccessLevel {
  READ,
  WRITE,
  NONE
}