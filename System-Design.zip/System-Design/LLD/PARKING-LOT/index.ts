import { ParkingLot } from "./parkingLot";
import { SpotType } from './enum';
import { Vehicle } from "./vehicle";

export class Main {
  private parkingLot: ParkingLot;
  constructor() {
    this.parkingLot = new ParkingLot([
      [
        {type: SpotType.CAR, count: 2},
        {type: SpotType.MOTORCYCLE, count: 2},
        {type: SpotType.TRUCK, count: 1},
      ],
      [
        {type: SpotType.CAR, count: 2},
        {type: SpotType.MOTORCYCLE, count: 1},
        {type: SpotType.TRUCK, count: 1},
      ]
    ])
    this.process()
  }
  process() {
    const c1 = new Vehicle(SpotType.CAR);
    const c2 = new Vehicle(SpotType.CAR);
    const c3 = new Vehicle(SpotType.CAR);
    const c4 = new Vehicle(SpotType.CAR);
    const c5 = new Vehicle(SpotType.CAR);
    const c6 = new Vehicle(SpotType.CAR);
    const m1 = new Vehicle(SpotType.MOTORCYCLE);
    const m2 = new Vehicle(SpotType.MOTORCYCLE);
    const m3 = new Vehicle(SpotType.MOTORCYCLE);
    const m4 = new Vehicle(SpotType.MOTORCYCLE);
    const t1 = new Vehicle(SpotType.TRUCK);
    const t2 = new Vehicle(SpotType.TRUCK);
    const t3 = new Vehicle(SpotType.TRUCK);
    this.parkingLot.availability();
    this.parkingLot.park(c1.id,c1.type);
    this.parkingLot.park(c2.id,c2.type);
    this.parkingLot.park(c3.id,c3.type);
    this.parkingLot.park(c4.id,c4.type);
    this.parkingLot.availability();
    this.parkingLot.park(c5.id,c5.type);
    this.parkingLot.unpark(c2.id);
    this.parkingLot.park(c5.id,c5.type);
    this.parkingLot.park(t1.id,t1.type);
    this.parkingLot.park(t2.id,t2.type);
    this.parkingLot.availability();
    this.parkingLot.park(t3.id,t3.type);
    this.parkingLot.unpark(t1.id);
    this.parkingLot.park(t3.id,t3.type);
    this.parkingLot.park(m1.id,m1.type);
    this.parkingLot.park(m2.id,m2.type);
    this.parkingLot.park(m3.id,m3.type);
    this.parkingLot.availability();
  }
}