import { randomUUID } from "crypto";
import { SpotType } from "./enum";

export class Vehicle {
  id: string;
  type: SpotType;
  constructor(type: SpotType) {
    this.id = randomUUID();
    this.type = type;
  }
}