import { SpotType } from "./enum"

export type SpotInfo = {
  type: SpotType;
  count: number;
}