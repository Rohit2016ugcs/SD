import { SpotType, Status } from "./enum";
import { Level } from "./level";
import { Spot } from "./spot";
import { SpotInfo } from "./type";

export class ParkingLot {
  private levels: Level[];
  private vehicleSpot: Map<string, Spot>;
  constructor(levelsInfo: SpotInfo[][]) {
    this.levels = [];
    this.vehicleSpot = new Map();
    for(let level = 0; level < levelsInfo.length; level++) {
      this.levels.push(new Level(level,levelsInfo[level]));
    }
  }
  availability() {
    console.log(this.levels.map(level => {
      return {
        level: level.level,
        ...Object.keys(SpotType).reduce((a,c) => ({...a,[c]: level.spots.filter(spot => spot.status==Status.AVAILABLE && spot.type == SpotType[c as keyof typeof SpotType]).length}), {})
      }
    }))
  }
  park(vehicleId: string, type: SpotType) {
    for(const level of this.levels) {
      const spot = level.spots.find(spot => spot.type == type && spot.status == Status.AVAILABLE);
      if(spot) {
        this.vehicleSpot.set(vehicleId,spot);
        spot.status=Status.BOOKED;
        console.log("spot allocated:- ",{ vehicleId, spotId: spot.id });
        break;
      }
    }
    if(!this.vehicleSpot.has(vehicleId)){
      console.log("no spot available for vehicleId:- ",vehicleId);
    }
  }
  unpark(vehicleId: string) {
    if(this.vehicleSpot.has(vehicleId)) {
      this.vehicleSpot.get(vehicleId)!.status=Status.AVAILABLE;
      this.vehicleSpot.delete(vehicleId);
      console.log("vehicle unparked");
    } else {
      console.log("vehicle not found");
    }
  }
}