import { randomUUID } from "crypto";
import { SpotType, Status } from "./enum";

export class Spot {
  id: string;
  type: SpotType;
  level: number;
  status: Status;
  constructor(type: SpotType, level: number) {
    this.id = randomUUID();
    this.type = type;
    this.level=level;
    this.status = Status.AVAILABLE;
  }
}