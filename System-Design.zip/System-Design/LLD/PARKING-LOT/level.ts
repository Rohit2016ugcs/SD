import { Spot } from "./spot";
import {  SpotInfo } from './type';

export class Level {
  level: number;
  spots: Spot[];
  constructor(level: number, spotInfo: SpotInfo[]) {
    this.level = level;
    this.spots = [];
    for(const { type , count } of spotInfo) {
      for(let i = 0; i < count; i++)this.spots.push(new Spot(type,level));
    }
  }
}