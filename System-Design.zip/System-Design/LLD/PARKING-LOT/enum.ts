export enum SpotType {
  CAR = "car",
  MOTORCYCLE = "motorcycle",
  TRUCK = "truck"
}
export const enum Status {
  AVAILABLE,
  BOOKED
}